<?php include('header.php'); ?>

	<!-- this is for welcome -->
	<div class="content">
		<article>
			<img src="img/welcome1.png" alt="welcome msg">
			<p class="text-justify">We enhances patient satisfaction. Patients no longer have to be worried about the wait times in the clinic. They can plan their daily schedule better. They spend less time waiting to meet the doctor.you can access the patient appointment information on any device. You should have the ability to reschedule or cancel appointments in the event of any emergency. We manage multiple locations and multiple doctors. Your clinic may be operational in multiple places and each clinic may have multiple doctors each of who is available in a particular time slot.
			</p>
		</article>


	
	</div><br>

	<!-- nivo slider starts -->
	<div class="col-md-12 sliderImg">
		<img src="img/docter11.jpg" alt="">
		<img src="img/doctor12.jpg" alt="">
		<img src="img/doctor13.jpg" alt="">
		<img src="img/doctor14.jpg"   alt="">
		<img src="img/doctor15.jpg" alt="">
		<img src="img/doctor16.jpg" alt="">
	</div>
	<!-- nivo slider ends -->

	<!-- main Content -->
	<div class="main_content">
		<div class="col-md-8">
			<article>
			<h3 style="font-weight: bold;font-family:inherit;">Finds Doctors from anywhere anytime!</h3><hr>
				<p class="text-justify">Doctors have a responsibility to society as a whole to consider their accountability and refrain from following tradition blindly. 
				We are trained medical experts who use the practice of medicine to preserve and restore people's health.
				The necessity for a universal definition is highlighted by the international mobility of both patients and physicians.
				The processes and curriculum of medical education can only be determined to create the individual qualified to fill that future function once the position of the doctor has been established.</p>
			</article>
		</div>
		<div class="col-md-4">
			<h3 class="text-center" style="font-weight:bold;font-family:inherit;">Doctors Appoinment...?</h3><hr>
			<ul class="text-justify">
				
				a consultation with a doctor, nurse, or other healthcare provider that was scheduled within a short period of time.
				Information about patients will be accessible to doctors with ease. And a fantastic location to keep this information is in an app. 
				Before an appointment, a doctor can access any information about a patient (name, age, medical history, course of treatment, insurance information, etc.).
			</ul>
		</div>

          
    </div>

 	<?php include('footer.php'); ?>


	
</div>	<!--  containerFluid Ends -->



	<script src="js/jquery-1.9.0.min.js"></script>
	<script src="js/bootstrap.min.js"></script>

	 
	
</body>
</html>