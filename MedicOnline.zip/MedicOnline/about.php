<?php include('header.php'); ?>





	<!-- this is for donor registraton -->
	<div class="main_content" style="background-color:#fff;">
		<h3 class="text-center" style="background-color:#272327;color: #fff;">About Us</h3>
		<div class="col-md-12">
			<div class="col-md-6">
				<img src="img/doctor30.jpg" alt="" class="img-responsive">
			</div>

			<div class="col-md-6">
				<article>
					<h3 style="color:#0616BC;">We are Beside you</h3>
					<p class="text-justify">Dispensaries provide outpatient treatment, whereas hospitals focus on inpatient care. 
					Hospitals and dispensaries are commonly located next to one another. Although it has not yet been fully implemented, the goal is for the two services to be completely separated. 
					The ineffective separation of hospital and dispensary (outpatient unit) duties in some hospitals burdens hospital services and makes it difficult to perform tasks at the community and primary-care levels, in particular. 
					Only 16 hospitals had successfully separated the hospital and the dispensary.</p>
				</article>
			</div>
		</div>


		<div class="col-md-12">
			<div class="col-md-6">
				<article>
					<h3 style="color:#0616BC;">24/7 hour service</h3>
					<p class="text-justify">Implementing a health policy and raising the standard of treatment and services both depend heavily on supervision. 
					  A top-down supervision structure was introduced in Rwanda. The levels of the building each watch over the level below them. A group from the district administrative unit handles supervision. 
					The managing administrator, the pharmacy manager, or other supervisors typically carry it out.
					Physician supervision is uncommon.</p>
				</article>
			</div>
			<div class="col-md-6">
				<img src="img/doctor31.jpg" alt="" class="img-responsive"><br>
			</div>
		</div>
          
    </div>
		
	
	
	

	
 <?php include('footer.php'); ?>


	
	</div><!--  containerFluid Ends -->




	<script src="js/bootstrap.min.js"></script>





	
</body>
</html>