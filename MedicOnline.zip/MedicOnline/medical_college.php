<?php include('header.php'); ?>


	<!-- mc info -->
	<div class="form-group mc">
		<h2 class="text-center" style="background-color:#272327;color: #fff;">Hospitals in Kigali</h2>

                              <table cellpadding="10" cellspacing="10" class="table table-hover">   

                                  <tr>
                                      <th>No.</th><th>Name</th><th>Acronym</th><th>Location</th></td>
                                  </tr>
                                  <tr>
                                      <td>01</td><td> MUHIMA HOSPITAL</td><td>MH</td><td>Kigali</td>
                                  </tr>
                                  <tr>
                                      <td>02</td><td>KACYIRU HOSPITAL</td><td>KH</td><td>Kigali</td>
                                  </tr>
                                  <tr>
                                      <td>03</td><td>KIBAGABAGA HOSPITAL</td><td>KH</td><td>Kigali</td>
                                  </tr>
                                  <tr>
                                      <td>04</td><td>NDERA HOSPITAL</td><td>NH</td><td>Kigali</td>
                                  </tr>
                                  <tr>
                                      <td>05</td><td>MASAKA HOSPITAL</td><td>MH</td><td>Kigali</td>
                                  </tr>
                                  <tr>
                                      <td>06</td><td>RWAMAGANA HOSPITAL</td><td>RH</td><td>Rwamagana</td>
                                  </tr>
                                  <tr>
                                      <td>07</td><td>La Croix du Sud Hospital</td><td>LCDSH</td><td>Kigali</td>
                                  </tr>
                                  <tr>
                                      <td>08</td><td>Legacy Clinics</td><td>LC</td><td>Kigali</td>
                                  </tr>
                                  
                                  
                              </table>
	</div>
	

    <!-- footer section --> 
			 <?php include('footer.php'); ?>
		<!-- footer section Ends--> 


	
	</div><!--  containerFluid Ends -->



	<script src="js/bootstrap.min.js"></script>
	
</body>
</html>